import React from 'react'
import '../styles/nav.css'
import { Outlet, Link } from 'react-router-dom';
import { HashLink } from 'react-router-hash-link';


const Nav = () => {
    return (
        <>
            <div className='nav'>
                <div className='logo'>
                    <img src='/nav/nav-zm.png' height={80} alt='zm-logo' />
                    <div>
                        <p className='zm-name'>zmqrcode.com</p>
                        <p >Your Security is Our Priority</p>
                    </div>
                </div>

                <ul className='nav-items'>
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="/about">About us</Link></li>
                    <li><Link to="/services">Services</Link></li>
                    <li><HashLink smooth to="/#faq">FAQ</HashLink></li>
                    <li><HashLink smooth to="/#contact">Contact us</HashLink></li>

                    <li><Link to="/login">Login</Link></li>
                </ul>
            </div>
            <Outlet />
        </>
    )
}

export default Nav;