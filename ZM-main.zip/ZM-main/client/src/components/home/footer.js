import React from 'react';
import { FaLinkedin, FaYoutube, FaInstagram, FaFacebook, FaTwitter } from 'react-icons/fa';
import { faPhoneAlt, faEnvelope, faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';



import '../../styles/Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div>
          <div className="stay-connected">
            <h2>Stay Connected</h2>
            <p>Sign up for our newsletter and be the first to hear about Offers, updates, and tips</p>
            <form className="newsletter-form">
              <input type="email" placeholder="Your email address" />
              <button type="submit">
                <img src="/footer/email.png" alt="Subscribe" />
              </button>
            </form>
          </div>
          <div className="join-community">
            <h2>Join The Community</h2>
            <div className="social-icons">
              <a href="#"><FaLinkedin /></a>
              <a href="#"><FaYoutube /></a>
              <a href="#"><FaInstagram /></a>
              <a href="#"><FaFacebook /></a>
              <a href="#"><FaTwitter /></a>
            </div>
          </div>
        </div>

        <div className="laptop-image-container">
        </div>
      </div>

      <div className='dummy'>
        <div className="company-details">
          <img src="/footer/ZMlogo.png" alt="" />
          <h3>ZM QR Code Services</h3>
          <p>Generate a unique QR Code for your brand with us...</p>
        </div>
        <div className='footer-links'>
          <div className="contact-us">
            <h2>Contact us</h2>
            <p>
              <FontAwesomeIcon icon={faPhoneAlt} /> <a href="tel:8688278529">86882 78529</a>
            </p>
            <p>
              <FontAwesomeIcon icon={faEnvelope} /> <a href="mailto:info@zmqrcodeservices.com">info@zmqrcodeservices.com</a>
            </p>
            <p>
              <FontAwesomeIcon icon={faMapMarkerAlt} /> Ramaseetha Complex, 4th Floor, 5/4, Arundelpet, Guntur, AP, India 522002
            </p>
          </div>

          <div className="company-links">
            <h2>Company</h2>
            <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#">About Us</a></li>
              <li><a href="#">Services</a></li>
              <li><a href="#">FAQs</a></li>
              <li><a href="#">Contact Us</a></li>
            </ul>
          </div>
          <div className="terms-links">
            <h2>Terms</h2>
            <ul>
              <li><a href="Terms">Terms And Conditions</a></li>
              <li><a href="Terms">Terms of Acceptable Usage</a></li>
              <li><a href="PP">Privacy Policy</a></li>
              <li><a href="CP">Cookie Policy</a></li>
            </ul>
          </div>
        </div>
      </div>


      <div className="footer-bottom">
        <p>© 2024. All Rights Reserved. ZM QR Code</p>
      </div>

    </footer>
  );
};

export default Footer;
