import React from 'react';
import '../../styles/header.css';

const Header = () => {
    return (
        <>
            <div className='header'>
                <div className='head'>
                    <h1>Generate a unique QR Code for your brand with us...</h1>
                    <h2>Your Security Is Our Priority</h2>
                    <button>Choose your QR type</button>
                </div>
                <img className='laptop' src="/header/header-laptop.png" height={300} alt='laptop' />
                <div className='tail'>
                    <button>About QR code</button>
                </div>
            </div>
        </>
    )
}

export default Header