import React from 'react'
import Header from './header';
import Contact from './contact';
import Support from './support';
import Footer from './footer';
import FAQSection from './faq';
import Services from './services';
import AboutUs from './AboutUs';

const Home = () => {
    return (
        <>
            <Header />
            <AboutUs />
            <Services />
            <FAQSection />
            <Support />
            <Contact />
            <Footer />
        </>
    )
}

export default Home