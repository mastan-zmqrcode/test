import React from 'react'
import '../../styles/contact.css'

const Contact = () => {
    return (
        <>
            <div id='contact'>
                <h1 className='contact-heading'>Contact us</h1>
                <div className='contact'>
                    <div className='image'>
                        <div className='contact-zm'>
                            <img src='/contact/contact-zm.png' alt='zm-logo' />
                            <div>
                                <p>ZM QR Code Services</p>
                                <p >Generate a unique QR code for your brand with us...</p>
                            </div>
                        </div>
                        <img src='/contact/contact-people.png' alt='people' height={570} />
                    </div>
                    <div className='form'>
                        <h2>Send us a message</h2>
                        {/* <label htmlFor='con-name'>Name</label> */}
                        <input type='text' id='con-name' placeholder='Name' />
                        {/* <label htmlFor='con-mobile'>Mobile</label> */}
                        <input type='text' id='con-mobile' placeholder='Mobile' />
                        {/* <label htmlFor='con-email'>Email</label> */}
                        <input type='text' id='con-email' placeholder='Email' />
                        {/* <label htmlFor='con-country'>Country</label> */}
                        <input type='text' id='con-country' placeholder='Country' />
                        {/* <label htmlFor='con-state'>State</label> */}
                        <input type='text' id='con-state' placeholder='State' />
                        {/* <label htmlFor='con-city'>City</label> */}
                        <input type='text' id='con-city' placeholder='City' />
                        {/* <label htmlFor='find'>How did you find us</label> */}
                        <input type='text' id='find' placeholder='How did you find us' />
                        {/* <label htmlFor='con-message'>Message</label> */}
                        <input type='text' id='con-message' placeholder='Message' />

                        <div>
                            <button>Send message</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Contact