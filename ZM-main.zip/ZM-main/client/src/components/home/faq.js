import React, { useState } from 'react';
import '../../styles/faq.css'; // Import your CSS file
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons'; // Assuming you have FontAwesome installed

const FAQSection = () => {
    const [activeQuestion, setActiveQuestion] = useState(null);
    const [selectedCategory, setSelectedCategory] = useState('accounts');
    const [isSearchVisible, setIsSearchVisible] = useState(false);

    const categories = {
        accounts: [
            { qn: "What is Lorem Ipsum?", ans: " Ipsum is simply dummy text of the printing and typesetting industry." },
            { qn: "What is Lorem Ipsum?", ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry." },
            { qn: "What is Lorem Ipsum?", ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry." }
        ],
        security: [
            { qn: "What is Lorem Ipsum?", ans: "Lorem  is simply dummy text of the printing and typesetting industry." },
            { qn: "What is Lorem Ipsum?", ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry." },
            { qn: "What is Lorem Ipsum?", ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry." }
        ],
        premium: [
            { qn: "What is Lorem Ipsum?", ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry." },
            { qn: "What is Lorem Ipsum?", ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry." },
            { qn: "What is Lorem Ipsum?", ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry." }
        ],
        qrCodes: [
            { qn: "What is Lorem Ipsum?", ans: " is simply dummy text of the printing and typesetting industry." },
            { qn: "What is Lorem Ipsum?", ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry." },
            { qn: "What is Lorem Ipsum?", ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry." }
        ]
    };

    const handleCategoryChange = (category) => {
        setSelectedCategory(category);
        setActiveQuestion(null); // Reset active question when category changes
    };

    const toggleQuestion = (index) => {
        setActiveQuestion(activeQuestion === index ? null : index);
    };

    return (
        <div id='faq' className="faq-section">
            <h2>Frequently Asked Questions</h2>
            <div className="faq-controls">
                <div className="faq-buttons">
                    <button className="faq-button" onClick={() => handleCategoryChange('accounts')}>Accounts</button>
                    <button className="faq-button" onClick={() => handleCategoryChange('premium')}>Premium</button>
                    <button className="faq-button" onClick={() => handleCategoryChange('qrCodes')}>QR Codes</button>
                    <button className="faq-button" onClick={() => handleCategoryChange('security')}>Security</button>
                </div>
                <div className="faq-search">
                    {isSearchVisible && <input type="text" placeholder="Search..." />}
                    <FontAwesomeIcon
                        icon={faSearch}
                        className="search-icon"
                        onClick={() => setIsSearchVisible(!isSearchVisible)}
                    />
                </div>
            </div>
            <div className="faq-items">
                {categories[selectedCategory].map((item, index) => (
                    <div className="faq-item" key={index}>
                        <div
                            className={`faq-question ${activeQuestion === index ? 'active' : ''}`}
                            onClick={() => toggleQuestion(index)}
                        >
                            {item.qn}
                        </div>
                        {activeQuestion === index && (
                            <div className="faq-answer">
                                {item.ans}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default FAQSection;
