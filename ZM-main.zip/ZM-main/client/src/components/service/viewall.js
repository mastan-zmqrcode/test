import React from 'react';
const ViewAll = () => (
  <div>
    <h1>ZM QR Code Services</h1>
    <p>As the preferred QR Code solution provider for leading global brands, we offer comprehensive services for all your QR Code marketing and business requirements.Enhance customer engagement and elevate scan rates by over 50% with our exclusive QR shapes and stickers.Gain deeper insights into your campaign performance with advanced real-time analytics.Streamline your QR operations with automated bulk uploads and folder organization.Begin with our free plan and seamlessly transition to customized paid options designed for businesses of all sizes.</p>
    
      <div>
        <h2>Video</h2>
        <p>Keep your special moments alive by sharing your videos and experiencing the laughter, joy, and adventures with your loved ones with our Unique QR Code.</p>
      </div>
      <div>
        <h2>Image Gallery</h2>
        <p>Create professional digital business cards quickly by utilizing pre-designed templates. Effortlessly connect with others, make a lasting impression, and establish valuable relationships.</p>
      </div>
      <div>
        <h2>Business</h2>
        <p>Turn your valuable photos into a timeless legacy by using a distinctive QR code. Just upload and scan to capture your memories in a single, shareable QR experience.</p>
      </div>
      <div>
        <h2>Document</h2>
        <p>sfve</p>
      </div>
      <div>
        <h2>Multi-URL</h2>
        <p>vrgetv</p>
      </div>
      <div>
        <h2>Location</h2>
        <p>vf</p>
      </div>
      <div>
        <h2>WiFi</h2>
        <p>asdfg</p>
      </div>
      <div>
        <h2>Document</h2>
        <p>asdfgh</p>
      </div>
      <div>
        <h2>vCard Plus</h2>
        <p>sadfghj</p>
      </div>
  </div>
);

export default ViewAll;