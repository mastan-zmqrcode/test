import './styles/App.css';
import React from "react";
import { Routes, Route } from 'react-router-dom';
import RegistrationForm from './components/authentication/registration';
import LoginPage from "./components/authentication/loginPage";
import Nav from './components/nav';
import NotFound from './components/notFound';
import Home from './components/home/home';


const App = () => {
  return (
    <Routes>
      <Route path='/' element={<Nav />}>
        {/* public routes */}
        <Route index element={<Home />} />
        <Route path='login' element={<LoginPage />} />
        <Route path='signup' element={<RegistrationForm />} />

        {/* catch all */}
        <Route patch='*' element={<NotFound />} />
      </Route>
    </Routes>
  );
};

export default App;